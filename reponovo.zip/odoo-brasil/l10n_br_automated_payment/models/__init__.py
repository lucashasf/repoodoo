# © 2018 Danimar Ribeiro, Trustcode
# Part of Trustcode. See LICENSE file for full copyright and licensing details.

from . import res_company
from . import res_partner
from . import account_move
from . import payment_transaction
from . import account_journal
from . import res_config_settings